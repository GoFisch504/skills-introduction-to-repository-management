Main class: GithubIntegration
=============================

.. autoclass:: github.GithubIntegration.GithubIntegration
